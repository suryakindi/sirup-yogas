<?php return array (
  'admin.admin-dashboard' => 'App\\Http\\Livewire\\Admin\\AdminDashboard',
  'cart-component' => 'App\\Http\\Livewire\\CartComponent',
  'checkout-component' => 'App\\Http\\Livewire\\CheckoutComponent',
  'contact-component' => 'App\\Http\\Livewire\\ContactComponent',
  'home-component' => 'App\\Http\\Livewire\\HomeComponent',
  'product-detail-component' => 'App\\Http\\Livewire\\ProductDetailComponent',
  'profile-component' => 'App\\Http\\Livewire\\ProfileComponent',
  'shop-component' => 'App\\Http\\Livewire\\ShopComponent',
  'user.user-dashboard' => 'App\\Http\\Livewire\\User\\UserDashboard',
);