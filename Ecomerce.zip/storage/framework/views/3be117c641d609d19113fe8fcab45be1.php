<div>
    <h1>User</h1>
</div>
<?php /**PATH C:\laragon\www\Ecomerce\resources\views/livewire/user/user-dashboard.blade.php ENDPATH**/ ?>