<div>
    <main class="main single-page">
        <div class="page-header breadcrumb-wrap">
            <div class="container">
                <div class="breadcrumb">
                    <a href="index.html" rel="nofollow">Home</a>                    
                    <span></span> Profil
                </div>
            </div>
        </div>
        <section class="section-padding">
            <div class="container pt-25">
                <div class="row">
                    <div class="col-lg-6 align-self-center mb-lg-0 mb-4">
                        <h6 class="mt-0 mb-15 text-uppercase font-sm text-brand wow fadeIn animated">Sirup Yogas</h6>
                        <h1 class="font-heading mb-40">
                           Sirup Yogas
                        </h1>
                        <p>Pabrik Sirup Yogas didirikan oleh Neindar Yogo Suharto, sebuah perusahaan yang mengkhususkan diri dalam produksi dan distribusi berbagai jenis sirup berkualitas tinggi. Berlokasi di Alamat: 6V7H+P5P, Ngelo, Karangbener, Kec. Bae, Kabupaten Kudus, Jawa Tengah 59323, Pabrik Sirup Yogas telah menjadi salah satu pelaku utama dalam industri minuman sirup di wilayah tersebut.</p>
                       
                    </div>
                    <div class="col-lg-6">
                        <img src="assets/imgs/about-1.png" alt="">
                    </div>
                </div>
            </div>
        </section>                
        
        
    </main>
</div>
<?php /**PATH C:\laragon\www\Ecomerce\resources\views/livewire/profile-component.blade.php ENDPATH**/ ?>