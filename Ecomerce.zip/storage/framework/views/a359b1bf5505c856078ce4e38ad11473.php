<div>
    
    <main class="main">
        <div class="page-header breadcrumb-wrap">
            <div class="container">
                <div class="breadcrumb">
                    <a href="index.html" rel="nofollow">Home</a>                    
                    <span></span> Contact us
                </div>
            </div>
        </div>                
        <section class="pt-50 pb-50">
            <div class="container">
                <div class="row">
                    <div class="col-xl-8 col-lg-10 m-auto">
                        <div class="contact-from-area padding-20-row-col wow FadeInUp">
                            <p>Contact Us</p>
                        <hr>
                           <p> Whatsapp  : 0857 1362 2235</p>
                           <p> Facebook  : <a href="https://facebook.com/">https://facebook.com/</a></p>
                           <p> Instagram : <a href="https://Instagram.com/">https://instagram.com/</a></p>  
                           <p> Email     : <a href="https://email.com/">https://email.com/</a></p>      
                        <hr>
                        <div class="mapouter"><div class="gmap_canvas"><iframe width="770" height="510" id="gmap_canvas" src="https://maps.google.com/maps?q=sirup yogas&t=&z=10&ie=UTF8&iwloc=&output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe><a href="https://2yu.co">2yu</a><br><style>.mapouter{position:relative;text-align:right;height:510px;width:770px;}</style><a href="https://embedgooglemap.2yu.co">html embed google map</a><style>.gmap_canvas {overflow:hidden;background:none!important;height:510px;width:770px;}</style></div></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
</div>
<?php /**PATH C:\laragon\www\Ecomerce\resources\views/livewire/contact-component.blade.php ENDPATH**/ ?>