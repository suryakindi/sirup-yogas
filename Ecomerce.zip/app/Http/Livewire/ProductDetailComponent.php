<?php

namespace App\Http\Livewire;

use Livewire\Component;
use App\Models\Product;

class ProductDetailComponent extends Component
{
    public $product;
    public function mount($id)
    {
        $this->product = Product::find($id);
    }

    public function render()
    {   
        $newproduct = Product::latest()->take(6)->get();
        $item = $this->product;
        
        return view('livewire.product-detail-component',compact('item', 'newproduct'));
    }
    
}
